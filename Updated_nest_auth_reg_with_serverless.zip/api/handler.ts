
import { handler } from '../serverless';

export const main = async (req, res) => {
  return handler(req, res);
};
