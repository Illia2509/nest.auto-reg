
import { Controller, Post, Get, Param, Body } from '@nestjs/common';
import { HealthDataService } from './health-data.service';

@Controller('health-data')
export class HealthDataController {
  constructor(private readonly healthDataService: HealthDataService) {}

  @Post('save-data')
  async saveData(@Body() payload: any): Promise<string> {
    await this.healthDataService.saveData(1, payload); // Хардкод користувача 1
    return 'Дані збережено';
  }

  @Get(':user_id')
  async getData(@Param('user_id') user_id: number) {
    return this.healthDataService.getData(user_id);
  }
}
