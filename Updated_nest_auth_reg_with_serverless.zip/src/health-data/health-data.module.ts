
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HealthDataService } from './health-data.service';
import { HealthDataController } from './health-data.controller';
import { HealthData } from './health-data.entity';

@Module({
  imports: [TypeOrmModule.forFeature([HealthData])],
  providers: [HealthDataService],
  controllers: [HealthDataController],
})
export class HealthDataModule {}
