
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class HealthData {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  user_id!: number;

  @Column()
  data_type!: string;

  @Column('bigint')
  date!: number;

  @Column('int')
  data!: number;
}
