import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { HealthData } from './health-data.entity';

@Injectable()
export class HealthDataService {
  constructor(
    @InjectRepository(HealthData)
    private healthDataRepository: Repository<HealthData>,
  ) {}

  async saveData(user_id: number, payload: any): Promise<void> {
    try {
      console.log('Payload received:', payload); // Лог вхідних даних
      const records: HealthData[] = [];

      // Обробка кожного типу даних
      (['heartRate', 'bloodOxygen'] as const).forEach((type) => {
        console.log(`Processing type: ${type}`);
        payload[type]?.forEach((item: { date: number; data: number }) => {
          console.log(`Processing item: ${JSON.stringify(item)}`);
          records.push(
            this.healthDataRepository.create({
              user_id,
              data_type: type,
              date: item.date,
              data: item.data,
            }),
          );
        });
      });

      console.log('Records to save:', records); // Лог даних для збереження
      await this.healthDataRepository.save(records);
      console.log('Data saved successfully'); // Лог успішного збереження
    } catch (error: any) { // Використання типу any для обробки помилок
      console.error('Error saving data:', error.message || error);
      throw error;
    }
  }

  async getData(user_id: number): Promise<any> {
    try {
      console.log('Fetching data for user:', user_id); // Лог запиту на отримання даних
      const result = await this.healthDataRepository.find({ where: { user_id } });
      console.log('Data fetched from DB:', result); // Лог отриманих даних

      const heartRate = result
        .filter((item) => item.data_type === 'heartRate')
        .map(({ date, data }) => ({ date, data }));

      const bloodOxygen = result
        .filter((item) => item.data_type === 'bloodOxygen')
        .map(({ date, data }) => ({ date, data }));

      return { heartRate, bloodOxygen };
    } catch (error: any) { // Використання типу any для обробки помилок
      console.error('Error fetching data:', error.message || error);
      throw error;
    }
  }
}
