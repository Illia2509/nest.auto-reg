
import { NestFactory } from '@nestjs/core';
import { AppModule } from './src/app.module';
import { ServerlessAdapter } from '@nestjs/platform-serverless';
import * as serverless from 'serverless-http';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors();
  await app.init();

  return serverless(app.getHttpAdapter().getInstance());
}

export const handler = bootstrap();
